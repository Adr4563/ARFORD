# -*- coding: utf-8 -*-
"""Notebook de metricas de la TRIVIA de Romeo."""
import nbformat as nbf
from nbformat.v4 import new_notebook, new_markdown_cell, new_code_cell

nb = new_notebook()
cells = []
def md(t): cells.append(new_markdown_cell(t))
def code(t): cells.append(new_code_cell(t))

md("""# Métricas de la trivia — Robot Romeo
**Sesión 8 nov 2026 · captura con `ROMEO_MEDIR=1`**

Solo métricas de la **trivia**. Este notebook lee los CSV crudos y genera las gráficas.

**Nodos del sistema:** `communication_node` (STT+TTS) · `expression_faces_node` (FER+caras) · `moving_control_node` (carrito) · `orchestrator_node` (afectiva PULSE/ROSE/AEB + LLM + trivia).""")

code("""import pandas as pd, numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

plt.rcParams.update({
    "figure.dpi": 110, "font.size": 11, "axes.spines.top": False,
    "axes.spines.right": False, "font.family": "DejaVu Sans",
})
GRIS="#2b3a52"; VERDE="#1ba378"; NARANJA="#e07a1a"; AZUL="#2a78d6"; ROJO="#c0392b"

BASE = Path(r".")   # misma carpeta del notebook
def ruta(n): return BASE / n

def eje_preguntas(ax, x):
    \"\"\"Una marca por pregunta en el eje X.\"\"\"
    x = np.asarray(x)
    ax.set_xticks(x); ax.tick_params(axis="x", labelsize=8)
    ax.set_xlim(x.min()-0.5, x.max()+0.5)
    ax.grid(axis="x", color="#e3e3e3", lw=0.6, zorder=0)
    ax.set_ylim(bottom=0)""")

md("## 1. Cargar los datos")

code("""# turnos (Pi): afectiva + LLM + tokens
filas = []
with open(ruta("turnos.csv"), encoding="utf-8", errors="replace") as f:
    next(f)
    for ln in f:
        nums=[]
        for x in ln.split(","):
            try: nums.append(float(x))
            except ValueError: pass
        if len(nums) < 4: continue
        ei = next((i for i,v in enumerate(nums) if v > 1e9), None)
        if ei is None or ei < 3: continue
        t_llm=nums[ei-1]; tok=nums[ei-3]; afect=nums[0]*1000
        if 50 <= t_llm <= 5000 and 1 <= tok <= 200:
            filas.append({"t_llm_ms":t_llm,"tokens_salida":tok,
                          "afectiva_ms": afect if afect < 3000 else np.nan})
turnos = pd.DataFrame(filas)
mod = pd.read_csv(ruta("modulos_pc.csv"))
tts = pd.read_csv(ruta("tts.csv"))
sis = pd.read_csv(ruta("sistema.csv"))
sis["min"] = (sis["t"] - sis["t"].iloc[0]) / 60
print("turnos:", len(turnos), "| modulos:", len(mod), "| tts:", len(tts), "| sistema:", len(sis))""")

md("""## 2. Comparación Rocha vs IA  —  ¿coincide la respuesta?

Para cada pregunta de la trivia, la respuesta **generada por el LLM** se compara con la **respuesta por defecto de Rocha** (del banco de preguntas). Un LLM juez decide si coinciden. Por categoría.""")

code("""# Datos de la comparacion Coincide / No coincide (27/30 = 90%).
# 'Reconocimiento musical' (0/2) es parte de 'Arte, musica y cultura' (3/3),
# asi que se fusionan: Arte, musica y cultura = 3/5.
cats = [
    ("Geografía",7,7),("Razonamiento matemático",6,6),("Arte, música y cultura",3,5),
    ("Ciencia y naturaleza",2,3),("Dilema del coche autónomo",2,2),("Juego de emociones",2,2),
    ("Deporte y entretenimiento",1,1),("Juego de imitación",1,1),
    ("Matemática: multiplicación",1,1),("Historia",1,1),("Cultura general",1,1),
]
dfc = pd.DataFrame(cats, columns=["categoria","coincide","total"])
dfc["no_coincide"] = dfc["total"] - dfc["coincide"]
dfc = dfc.iloc[::-1].reset_index(drop=True)  # orden como el ejemplo (mayor arriba)

fig, ax = plt.subplots(figsize=(8,6.5))
y = np.arange(len(dfc))
ax.barh(y, dfc["coincide"], color=VERDE, zorder=3, label="Coincide")
ax.barh(y, dfc["no_coincide"], left=dfc["coincide"], color=NARANJA, zorder=3, label="No coincide")
for i,(c,t) in enumerate(zip(dfc["coincide"], dfc["total"])):
    ax.text(t+0.1, i, f"{c}/{t}", va="center", fontsize=10, color="#333")
ax.set_yticks(y); ax.set_yticklabels(dfc["categoria"], fontsize=10)
co, to = dfc["coincide"].sum(), dfc["total"].sum()
ax.set_xlabel(f"Preguntas (N = {to})")
ax.legend(loc="upper center", bbox_to_anchor=(0.5,1.08), ncol=2, frameon=False, fontsize=11)
ax.set_xlim(0, dfc["total"].max()+1)
plt.tight_layout(); plt.show()
print(f"Coincidencia Rocha vs IA: {co}/{to} = {100*co/to:.0f}%")""")

md("""## 3. Datos por turno

Se arma una tabla con el tiempo de cada etapa en cada pregunta, cruzando los
CSV por el **texto de la frase** (los relojes de Pi y PC están desfasados, pero
la frase es la misma clave). Esta tabla alimenta las líneas de tiempo siguientes.""")

code("""import csv, re
def norm(s): return s.strip().lower()[:40]

# STT/SER/TER por frase (PC)
mod_por_frase = {}
with open(ruta("modulos_pc.csv"), encoding="utf-8", errors="replace") as f:
    r = csv.reader(f); next(r)
    for row in r:
        if len(row) > 5:
            try:
                mod_por_frase[norm(row[5])] = {
                    "stt": float(row[2]) if row[2] else np.nan,
                    "ser": float(row[3]) if row[3] else np.nan,
                    "ter": float(row[4]) if row[4] else np.nan}
            except ValueError: pass

# ventana FER por turno (del log, en orden de aparicion)
fer_vent = []
try:
    log = open(ruta("romeo_run.log"), encoding="utf-8", errors="replace").read()
    fer_vent = [float(m.group(1))*1000 for m in re.finditer(r"FER: \\d+ cuadros en ([\\d.]+) s", log)]
except FileNotFoundError: pass

# TTS por turno (en orden; tts.csv no trae texto)
tts_vals = pd.to_numeric(tts["t_tts_ms"], errors="coerce").dropna().tolist()

filas = []
with open(ruta("turnos.csv"), encoding="utf-8", errors="replace") as f:
    next(f)
    for i, ln in enumerate(f):
        partes = ln.rstrip("\\n").split(",")
        texto = partes[-1].strip()
        nums = []
        for x in partes:
            try: nums.append(float(x))
            except ValueError: pass
        ei = next((j for j,v in enumerate(nums) if v > 1e9), None)
        if ei is None or ei < 3: continue
        m = mod_por_frase.get(norm(texto), {"stt":np.nan,"ser":np.nan,"ter":np.nan})
        filas.append({
            "pregunta": len(filas)+1,
            "STT": m["stt"], "SER": m["ser"], "TER": m["ter"],
            "afectiva": nums[0]*1000 if nums[0]*1000 < 3000 else np.nan,
            "LLM": nums[ei-1],
            "TTS": tts_vals[i] if i < len(tts_vals) else np.nan,
            "FER": fer_vent[i] if i < len(fer_vent) else np.nan,
        })
dft = pd.DataFrame(filas)
# por nodo
dft["communication_node"] = dft[["STT","TTS"]].sum(axis=1, min_count=1)
dft["orchestrator_node"]  = dft[["afectiva","LLM"]].sum(axis=1, min_count=1)
dft["expression_faces_node"] = dft["FER"]
print(f"{len(dft)} turnos."); dft.head()""")

md("## 4. Línea de tiempo por nodo")

code("""fig, ax = plt.subplots(figsize=(12,4.5))
x = dft["pregunta"]
ax.plot(x, dft["communication_node"], color=AZUL, lw=1.8, marker="o", ms=3, label="communication_node (STT+TTS)")
ax.plot(x, dft["orchestrator_node"], color=VERDE, lw=1.8, marker="o", ms=3, label="orchestrator_node (afectiva+LLM)")
ax.plot(x, dft["expression_faces_node"], color=NARANJA, lw=1.8, marker="o", ms=3, label="expression_faces_node (FER)")
eje_preguntas(ax, x)
ax.set_xlabel("Pregunta (turno)"); ax.set_ylabel("Tiempo del nodo (ms)")
ax.set_title("Tiempo usado por cada nodo a lo largo de la trivia")
ax.legend(frameon=False, fontsize=9)
plt.tight_layout(); plt.show()
print("moving_control_node (carrito): no interviene en la trivia.")""")

md("## 5. Línea de tiempo — percepción emocional (TER, FER, SER)")

md("""Vista en 3D: cada modelo va en su propio carril (eje de profundidad) y la
altura es el tiempo en **escala logarítmica** (log10 ms), para que TER (pocos ms)
y FER (cientos/miles de ms) se vean juntos sin aplastarse.""")

code("""from mpl_toolkits.mplot3d.art3d import Poly3DCollection

def linea_3d_log(series, titulo, figsize=(12,7)):
    \"\"\"Una línea por carril (eje Y) con la altura en log10(ms). series: [(nombre, columna, color)].\"\"\"
    fig = plt.figure(figsize=figsize)
    ax = fig.add_subplot(projection="3d")
    x = dft["pregunta"].to_numpy()
    datos = []
    for k, (nombre, col, color) in enumerate(series):
        v = dft[col].to_numpy(dtype=float)
        ok = np.isfinite(v) & (v > 0)
        if not ok.any(): continue
        xs, zs = x[ok], np.log10(v[ok])
        ax.plot(xs, np.full(len(xs), k, dtype=float), zs, color=color, lw=2.2,
                marker="o", ms=3.5, label=nombre)
        datos.append((k, col, color, xs, zs))
    z0 = np.floor(min(d[4].min() for d in datos))
    z1 = np.ceil(max(d[4].max() for d in datos))
    for k, _, color, xs, zs in datos:
        verts = [list(zip(xs, [k]*len(xs), zs)) + [(xs[-1], k, z0), (xs[0], k, z0)]]
        ax.add_collection3d(Poly3DCollection(verts, color=color, alpha=0.18))
    ax.set_zlim(z0, z1)
    ticks = np.arange(z0, z1+1)
    ax.set_zticks(ticks); ax.set_zticklabels([f"{10**t:g}" for t in ticks])
    ax.set_xticks(x); ax.tick_params(axis="x", labelsize=6, pad=0)
    ax.set_yticks(range(len(series))); ax.set_yticklabels([s[1] for s in series])
    ax.set_xlabel("Pregunta (turno)", labelpad=10); ax.set_ylabel("Modelo", labelpad=8)
    ax.set_zlabel("Tiempo (ms, escala log)", labelpad=10)
    ax.set_title(titulo)
    ax.view_init(elev=22, azim=-58)
    ax.legend(frameon=False, fontsize=9, loc="upper left")
    plt.tight_layout(); plt.show()
    for _, col, _, _, zs in datos:
        v = 10**zs
        print(f"{col}: mediana {np.median(v):.1f} ms  (min {v.min():.1f}, max {v.max():.1f})")

linea_3d_log([("TER (texto)", "TER", VERDE), ("SER (voz)", "SER", NARANJA),
              ("FER (ventana cámara)", "FER", AZUL)],
             "Percepción emocional por turno: TER, SER, FER (3D, log)")""")

md("""## 6. Línea de tiempo — capa afectiva con sus entradas

La capa afectiva (PULSE+ROSE+AEB) junto con sus tres entradas de percepción
(TER, SER, FER), en la misma vista 3D con escala logarítmica: cada una en su
carril. Se ve que la afectiva es casi instantánea (aritmética) frente al tiempo
que tardan los clasificadores que la alimentan.""")

code("""linea_3d_log([("TER (texto)", "TER", VERDE), ("SER (voz)", "SER", NARANJA),
              ("FER (cámara)", "FER", AZUL),
              ("Capa afectiva (PULSE+ROSE+AEB)", "afectiva", "#6a5aa0")],
             "Capa afectiva y sus entradas (TER, SER, FER) por turno (3D, log)",
             figsize=(12,7.5))
print(f"Capa afectiva: promedio {dft['afectiva'].mean():.2f} ms (es aritmética)")""")

md("## 7. Línea de tiempo — STT, TTS y LLM durante la trivia")

code("""fig, ax = plt.subplots(figsize=(12,4.5))
x = dft["pregunta"]
ax.plot(x, dft["STT"], color=VERDE, lw=1.8, marker="o", ms=3, label="STT (voz→texto)")
ax.plot(x, dft["LLM"], color=NARANJA, lw=1.8, marker="o", ms=3, label="LLM (gemma3:4b)")
ax.plot(x, dft["TTS"], color=AZUL, lw=1.8, marker="o", ms=3, label="TTS (voz)")
eje_preguntas(ax, x)
ax.set_xlabel("Pregunta (turno)"); ax.set_ylabel("Tiempo (ms)")
ax.set_title("STT, TTS y LLM a lo largo de la sesión de trivia")
ax.legend(frameon=False, fontsize=9)
plt.tight_layout(); plt.show()""")

md("## 8. Tokens del LLM")

code("""fig, axs = plt.subplots(1, 2, figsize=(12,4.3))
x = turnos["tokens_salida"].values; yv = turnos["t_llm_ms"].values
axs[0].scatter(x, yv, color=VERDE, s=42, alpha=0.85, zorder=3)
if len(x) > 2:
    b,a = np.polyfit(x,yv,1); xs=np.array([x.min(),x.max()])
    axs[0].plot(xs, a+b*xs, color=GRIS, lw=1.6)
    r = np.corrcoef(x,yv)[0,1]
    axs[0].text(0.05,0.92,f"r = {r:.2f}\\n{b:.1f} ms/token + {a:.0f} ms",
                transform=axs[0].transAxes, va="top", fontsize=10)
axs[0].set_xlabel("Tokens de salida"); axs[0].set_ylabel("Tiempo del LLM (ms)")
axs[0].set_title("Tiempo del LLM vs tokens")
axs[1].hist(x, bins=12, color=NARANJA, zorder=3, edgecolor="white")
axs[1].axvline(np.median(x), color=GRIS, lw=1.4, ls="--")
axs[1].text(np.median(x)+0.4, axs[1].get_ylim()[1]*0.88, f"mediana {np.median(x):.0f}", fontsize=9, color=GRIS)
axs[1].set_xlabel("Tokens de salida"); axs[1].set_ylabel("Frecuencia (turnos)")
axs[1].set_title("Distribución de tokens por respuesta")
plt.tight_layout(); plt.show()""")

md("""## 9. Recursos de la Raspberry Pi (de inicio a fin)

CPU total, proceso de cámara (FER), temperatura y RAM durante la sesión.""")

code("""tiene_temp = (sis["temp_c"] > 0).any()
ram_gb = sis["ram_usada_mb"] / 1024
ram_total_gb = sis["ram_total_mb"].iloc[0]/1024 if "ram_total_mb" in sis.columns else 8

fig, axs = plt.subplots(3, 1, figsize=(10,8), sharex=True)
# (1) CPU total + camara
axs[0].plot(sis["min"], sis["cpu_total_pct"], color=GRIS, lw=1, label="CPU total (%)")
axs[0].plot(sis["min"], sis["cpu_camara_pct"], color=NARANJA, lw=1.6, label="Proceso de cámara (% de un núcleo)")
axs[0].set_ylabel("CPU (%)")
axs[0].legend(loc="upper center", bbox_to_anchor=(0.5,1.35), ncol=1, frameon=False, fontsize=10)
# (2) Temperatura
if tiene_temp:
    axs[1].plot(sis["min"], sis["temp_c"], color=NARANJA, lw=1.3)
    axs[1].axhline(80, color=GRIS, ls="--", lw=1)
    axs[1].text(sis["min"].max(), 80.4, "80 °C", ha="right", fontsize=9, color=GRIS)
    axs[1].set_ylabel("Temp. (°C)")
else:
    axs[1].text(0.5,0.5,"Temperatura no capturada en esta corrida\\n(bug del recolector ya corregido; lectura directa 73.5 °C, pico ~80 °C)",
                transform=axs[1].transAxes, ha="center", va="center", fontsize=10, color=ROJO)
    axs[1].set_ylabel("Temp. (°C)"); axs[1].set_yticks([])
# (3) RAM
axs[2].plot(sis["min"], ram_gb, color=AZUL, lw=1.4)
axs[2].set_ylabel("RAM (GB)"); axs[2].set_ylim(0, ram_total_gb)
axs[2].set_xlabel("Minutos desde el inicio del muestreo")
plt.tight_layout(); plt.show()

print("Recursos:")
print(f"  CPU total:  mediana {sis['cpu_total_pct'].median():.1f}%  max {sis['cpu_total_pct'].max():.1f}%")
print(f"  CPU camara: mediana {sis['cpu_camara_pct'].median():.1f}%  max {sis['cpu_camara_pct'].max():.1f}%")
print(f"  RAM usada:  mediana {sis['ram_usada_mb'].median():.0f} MB  max {sis['ram_usada_mb'].max():.0f} MB")""")

md("## 10. Tabla resumen (trivia)")

code("""def prom1(s):
    s = pd.to_numeric(s, errors="coerce").dropna()
    return round(s.mean(),1) if len(s) else np.nan

tabla = []
for nombre, serie, unidad, nodo in [
    ("STT (voz→texto)", mod["t_stt_ms"], "ms", "communication / PC"),
    ("SER (emoción voz)", mod["t_ser_ms"], "ms", "communication / PC"),
    ("TER (emoción texto)", mod["t_ter_ms"], "ms", "communication / PC"),
    ("Afectiva PULSE+ROSE+AEB", turnos["afectiva_ms"], "ms", "orchestrator / Pi"),
    ("Respuesta LLM", turnos["t_llm_ms"], "ms", "orchestrator / Pi→PC"),
    ("Síntesis TTS", tts["t_tts_ms"], "ms", "communication / PC"),
    ("Tokens de salida", turnos["tokens_salida"], "tokens", "orchestrator"),
    ("CPU total Pi", sis["cpu_total_pct"], "%", "Raspberry"),
    ("CPU cámara/FER", sis["cpu_camara_pct"], "%", "expression / IMX500"),
    ("RAM usada Pi", sis["ram_usada_mb"], "MB", "Raspberry"),
]:
    tabla.append([nombre, prom1(serie), unidad, nodo])
df = pd.DataFrame(tabla, columns=["Indicador","Promedio","Unidad","Nodo / máquina"])
print("Coincidencia Rocha vs IA: 27/30 = 90%\\n")
df""")

nb["cells"] = cells
out = r"C:\Users\Adrian\AppData\Local\Temp\claude\a962a074445c657d\fe43f463-0b50-4410-acfb-ddfb7c2c1547\scratchpad\metricas\metricas_trivia_romeo.ipynb"
with open(out, "w", encoding="utf-8") as f:
    nbf.write(nb, f)
print("notebook creado:", out, "| celdas:", len(cells))
